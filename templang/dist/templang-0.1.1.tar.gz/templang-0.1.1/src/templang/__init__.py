"""
### templang
> A simple annotation-based language to generate code from templates
"""
from .main import parse